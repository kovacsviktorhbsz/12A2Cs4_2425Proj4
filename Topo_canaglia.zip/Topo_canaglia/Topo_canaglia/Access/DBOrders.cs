﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topo_canaglia.Model;

namespace Topo_canaglia.Access
{
    internal class DBOrders : DBAccessor<Orders>
    {
        public DBOrders(DbConnection connection) : base(connection)
        {

        }

        public override Orders Create(Orders obj)
        {
            using(var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = $"INSERT INTO orders VALUES('{obj.Oid}','{obj.Cid}','{obj.Fid}','{obj.Date}','{obj.Quantity}','{obj.Chid}');";
                cmd.ExecuteNonQuery();
                return obj;   
            }
        }

        public override Orders Delete(int id)
        {
            Orders order = Read().FirstOrDefault(o => o.Oid == id);
            if (order != null)
            {
                var cmd = Connection.CreateCommand();
                cmd.CommandText = $"DELETE FROM orders WHERE oid = {id};";
                var rowCount = cmd.ExecuteNonQuery();
            }
            return order;
        }

        public override IEnumerable<Orders> Read()
        {
            var result = new List<Orders>();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = "SELECT * FROM orders;";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Orders
                        {
                            Oid = reader.GetInt32(0),
                            Cid = reader.GetInt32(1),
                            Fid = reader.GetInt32(2),
                            Date = reader.GetDateTime(3).ToString(),
                            Quantity = reader.GetInt32(4),
                            Chid = reader.GetInt32(5)
                        });
                    }
                }
            }
            return result;
        }

        public override Orders Update(int id, Orders obj)
        {
            throw new NotImplementedException();
        }
    }
}
