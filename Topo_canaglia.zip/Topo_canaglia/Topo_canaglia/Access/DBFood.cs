﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using Topo_canaglia.Model;
using MySqlX.XDevAPI.Common;

namespace Topo_canaglia.Access
{
    internal class DBFood : DBAccessor<Food>
    {
        public DBFood(DbConnection connection) : base(connection)
        {

        }

        public override IEnumerable<Food> Read()
        {
            var result = new List<Food>();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = "SELECT * FROM food;";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Food
                        {
                            FId = reader.GetInt32(0),
                            FName = reader.GetString(1),
                            Category = reader.GetString(2),
                            Cost = reader.GetInt32(3),
                            Cuisine = reader.GetString(4)
                        });
                    }
                }
            }
            return result;
        }
        public List<Food> ReadByCategory()
            {
                var result = new List<Food>();
             
                using(var cmd = Connection.CreateCommand())
                {
                    cmd.CommandText = "SELECT * FROM food ORDER BY category;";
                    using(var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            result.Add(new Food 
                            {
                                FId = reader.GetInt32(0),
                                FName = reader.GetString(1),
                                Category = reader.GetString(2),
                                Cost = reader.GetInt32(3),
                                Cuisine = reader.GetString(4)
                            });
                        }
                    }
                }
                return result;
            }


        public override Food Update(int id, Food obj)
        {
            throw new NotImplementedException();
        }
        public override Food Create(Food obj)
        {
            throw new NotImplementedException();
        }
        public override Food Delete(int id)
        {
            throw new NotImplementedException();
        }
    }
}
