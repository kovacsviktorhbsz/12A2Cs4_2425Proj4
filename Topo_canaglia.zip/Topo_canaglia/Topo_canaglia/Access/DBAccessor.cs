﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Topo_canaglia.Access
{
    abstract internal class DBAccessor<T> where T : class
    {
        protected DbConnection Connection { get; private set; }
        abstract public T Create(T obj);
        abstract public IEnumerable<T> Read();
        abstract public T Update(int id, T obj);
        abstract public T Delete(int id);

        protected DBAccessor(DbConnection connection)
        {
            Connection = connection;
        }
    }
}
