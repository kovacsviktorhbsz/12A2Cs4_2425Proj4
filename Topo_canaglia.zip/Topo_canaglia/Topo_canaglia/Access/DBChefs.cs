﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topo_canaglia.Model;
using System.Data.Common;

namespace Topo_canaglia.Access
{
    class DBChefs : DBAccessor<Chefs>
    {
        public DBChefs(DbConnection connection) : base(connection)
        {

        }

        public override IEnumerable<Chefs> Read()
        {
            var result = new List<Chefs>();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = "SELECT * FROM chefs;";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Chefs
                        {
                            ChId = reader.GetInt32(0),
                            ChName = reader.GetString(1),
                            EMail = reader.GetString(2),
                            MichelinStars = reader.GetInt32(3)
                        });
                    }
                }
            }
            return result;
        }

        public override Chefs Create(Chefs obj)
        {
            throw new NotImplementedException();
        }
        public override Chefs Delete(int id)
        {
            throw new NotImplementedException();
        }
        public override Chefs Update(int id, Chefs obj)
        {
            throw new NotImplementedException();
        }
    }
}
