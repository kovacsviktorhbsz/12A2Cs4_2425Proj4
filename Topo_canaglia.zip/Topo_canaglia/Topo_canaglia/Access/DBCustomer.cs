﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topo_canaglia.Model;

namespace Topo_canaglia.Access
{
    internal class DBCustomer : DBAccessor<Customer>
    {
        public DBCustomer(DbConnection connection) : base(connection)
        {

        }


        public override IEnumerable<Customer> Read()
        {
            var result = new List<Customer>();

            using (var cmd = Connection.CreateCommand())
            {
                cmd.CommandText = "SELECT * FROM customer;";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        result.Add(new Customer
                        {
                            CId = reader.GetInt32(0),
                            CNme = reader.GetString(1),
                            EMail = reader.GetString(2),
                            Phonenummer = reader.GetInt32(3)
                        });
                    }
                }
            }
            return result;
        }
        public override Customer Create(Customer obj)
        {
            throw new NotImplementedException();
        }
        public override Customer Delete(int id)
        {
            throw new NotImplementedException();
        }
        public override Customer Update(int id, Customer obj)
        {
            throw new NotImplementedException();
        }
    }
}
