﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using Topo_canaglia.Access;
using Topo_canaglia.Model;

namespace Topo_canaglia
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const string connectionString = "server=localhost:3306,localhost:3307;uid=root;pwd=;database=restaurant";
        List<Food> CartItems = new List<Food>();
        private List<CartItem> cartItems = new List<CartItem>();
        int orderCount = 1;

        public MainWindow()
        {
            InitializeComponent();

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dbFood = new DBFood(connection);
                var dbOrder = new DBOrders(connection);

                LBFood.ItemsSource = dbFood.ReadByCategory().ToList();
                LBCategory.ItemsSource = dbFood.Read().Select(n => n.Category).Distinct().ToList();

                var orders = dbOrder.Read();

                if (orders.Count() != 0)
                {
                    orderCount = orders.Count()+1;
                }
            }
        }
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }
        private void btnMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void LBFood_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LBFood.SelectedItem != null)
            {
                var selectedFood = LBFood.SelectedItem as Food;
                PUItemselectionsView.IsOpen = true;
                PUItemselectionsView.Visibility = Visibility.Visible;

                TBselectedFood.Text =
                    $"Az általad választott tétel: {selectedFood.FName}.\n" +
                    $"Jellemzők: {selectedFood.Cuisine} - {selectedFood.Category}.\n" +
                    $"Ára: {selectedFood.Cost} / adag.";
            }
        }
        private void BTNItemSelectionsCancel(object sender, RoutedEventArgs e)
        {
            TBquantity.Text = "";
            PUItemselectionsView.IsOpen = false;
            PUItemselectionsView.Visibility = Visibility.Collapsed;
            LBFood.SelectedItem = null;
        }
        private void BTNItemSelectionAgree_Click(object sender, RoutedEventArgs e)
        {
            if (LBFood.SelectedItem is Food selectedFood && int.TryParse(TBquantity.Text, out int quantity))
            {
                var existingItem = cartItems.FirstOrDefault(item => item.Food.FName == selectedFood.FName);

                if (existingItem != null)
                {
                    existingItem.Quantity += quantity;
                }
                else
                {
                    cartItems.Add(new CartItem { Food = selectedFood, Quantity = quantity });
                }
                UpdateCartUI();

                TBquantity.Text = "";
                PUItemselectionsView.IsOpen = false;
                PUItemselectionsView.Visibility = Visibility.Collapsed;
                LBFood.SelectedItem = null;
            }
        }
        private void UpdateCartUI()
        {
            STOrders.Children.Clear();

            foreach (var item in cartItems)
            {
                var existingCartItem = STOrders.Children.OfType<Border>().FirstOrDefault(b =>
                {
                    var textBlocks = ((StackPanel)((StackPanel)b.Child).Children[0]).Children.OfType<TextBlock>().ToList();
                    var foodName = textBlocks[0].Text;
                    return foodName.Contains(item.Food.FName);
                });

                if (existingCartItem != null)
                {
                    var textBlocks = ((StackPanel)((StackPanel)existingCartItem.Child).Children[0]).Children.OfType<TextBlock>().ToList();
                    textBlocks[1].Text = $"🧾 Mennyiség: {item.Quantity}";
                    textBlocks[2].Text = $"💰 Összesen: {item.Food.Cost * item.Quantity} Ft";
                }
                else
                {
                    var itemPanel = new StackPanel { Orientation = Orientation.Horizontal };

                    var infoPanel = new StackPanel
                    {
                        Orientation = Orientation.Vertical,
                        Margin = new Thickness(0, 0, 10, 0),
                        Children =
                {
                    new TextBlock { Text = $"🍽️ {item.Food.FName}", FontSize = 16, FontWeight = FontWeights.Bold },
                    new TextBlock { Text = $"🧾 Mennyiség: {item.Quantity}", FontSize = 14 },
                    new TextBlock { Text = $"💰 Összesen: {item.Food.Cost * item.Quantity} Ft", FontSize = 14 }
                }
                    };

                    var deleteBtn = new Button
                    {
                        Content = "❌",
                        Background = Brushes.Transparent,
                        BorderThickness = new Thickness(0),
                        Foreground = Brushes.Red,
                        FontSize = 16,
                        Cursor = Cursors.Hand,
                        VerticalAlignment = VerticalAlignment.Bottom,
                        HorizontalAlignment = HorizontalAlignment.Right
                    };

                    deleteBtn.Click += (s, e) =>
                    {
                        var button = (Button)s;
                        var itemP = (StackPanel)button.Parent;
                        var borderToRemove = (Border)itemP.Parent;


                        STOrders.Children.Remove(borderToRemove);

                        cartItems.Remove(item);
                    };

                    itemPanel.Children.Add(infoPanel);
                    itemPanel.Children.Add(deleteBtn);

                    var cartItem = new Border
                    {
                        Margin = new Thickness(5),
                        Padding = new Thickness(10),
                        Background = new SolidColorBrush(Color.FromArgb(150, 255, 255, 255)),
                        CornerRadius = new CornerRadius(10),
                        Child = itemPanel
                    };

                    STOrders.Children.Add(cartItem);
                }
            }
        }
        private void BTNCart_Click(object sender, RoutedEventArgs e)
        {
            PUCart.IsOpen = true;
            PUCart.Visibility = Visibility.Visible;
        }
        private void BTNCartBack_Click(object sender, RoutedEventArgs e)
        {
            PUCart.IsOpen = false;
            PUCart.Visibility = Visibility.Collapsed;
        }
        private void BTNCartAgree_Click(object sender, RoutedEventArgs e)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dborder = new DBOrders(connection);

                foreach (var item in cartItems)
                {
                    dborder.Create(new Orders()
                    {
                        Oid = orderCount++,
                        Cid = new Random().Next(1, 22),
                        Fid = item.Food.FId,
                        Date = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                        Quantity = item.Quantity,
                        Chid = new Random().Next(1, 4)
                    });
                }

            }

            STOrders.Children.Clear();
            PUCart.IsOpen = false;
            PUCart.Visibility = Visibility.Collapsed;
            cartItems.Clear();
        }
        private void BTNHistory_Click(object sender, RoutedEventArgs e)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dbOrder = new DBOrders(connection);
                var dbFood = new DBFood(connection);
                var dbCustomer = new DBCustomer(connection);
                var dbChef = new DBChefs(connection);

                var orders = dbOrder.Read();
                var orderMatchUp = orders.Select(o =>
                {
                    return new
                    {
                        Oid = o.Oid,
                        Customer = dbCustomer.Read().FirstOrDefault(c => c.CId == o.Cid).CNme ?? "Nincs ilyen vendég!",
                        FoodName = dbFood.Read().FirstOrDefault(f => f.FId == o.Fid).FName ?? "Nincs ilyen étel!",
                        Quantity = o.Quantity,
                        Date = o.Date,
                        ChefName = dbChef.Read().FirstOrDefault(c => c.ChId == o.Chid).ChName ?? "Ez a séf nem itt dolgozik!"
                    };
                }).ToList();

                OrderHistoryListView.ItemsSource = orderMatchUp;
            }

            PUHistory.IsOpen = true;
            PUHistory.Visibility = Visibility.Visible;
        }
        private void BTNHistoryBack_Click(object sender, RoutedEventArgs e)
        {
            PUHistory.IsOpen = false;
            PUHistory.Visibility = Visibility.Collapsed;
        }
        private void LBCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedItem = LBCategory.SelectedItem;

            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dbFood = new DBFood(connection);

                switch (selectedItem)
                {
                    case "Előétel":
                        LBFood.ItemsSource = dbFood.Read().Where(f => f.Category == "Előétel");
                        break;

                    case "Főétel":
                        LBFood.ItemsSource = dbFood.Read().Where(f => f.Category == "Főétel");
                        break;

                    case "Desszert":
                        LBFood.ItemsSource = dbFood.Read().Where(f => f.Category == "Desszert");
                        break;

                    default:
                        LBFood.ItemsSource = dbFood.Read();
                        break;
                }
            }
        }
        private void BTNDefaultCategory_Click(object sender, RoutedEventArgs e)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dbFood = new DBFood(connection);
                LBFood.ItemsSource = dbFood.Read();
            }
        }
        private void BTNOrderDelete_Click(object sender, RoutedEventArgs e)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                var dbOrder = new DBOrders(connection);
                var dbFood = new DBFood(connection);
                var dbCustomer = new DBCustomer(connection);
                var dbChef = new DBChefs(connection);

                var selectedItem = OrderHistoryListView.SelectedItem;
                if(selectedItem != null)
                {
                    dynamic order = selectedItem;
                    dbOrder.Delete(order.Oid);
                }

                var orders = dbOrder.Read();
                var orderMatchUp = orders.Select(o =>
                {
                    return new
                    {
                        Oid = o.Oid,
                        Customer = dbCustomer.Read().FirstOrDefault(c => c.CId == o.Cid).CNme ?? "Nincs ilyen vendég!",
                        FoodName = dbFood.Read().FirstOrDefault(f => f.FId == o.Fid).FName ?? "Nincs ilyen étel!",
                        Quantity = o.Quantity,
                        Date = o.Date,
                        ChefName = dbChef.Read().FirstOrDefault(c => c.ChId == o.Chid).ChName ?? "Ez a séf nem itt dolgozik!"
                    };
                }).ToList();

                OrderHistoryListView.ItemsSource = orderMatchUp;
            }
        }
    }
}
