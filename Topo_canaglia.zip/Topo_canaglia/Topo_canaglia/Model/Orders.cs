﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Topo_canaglia.Model
{
    internal class Orders
    {
        public int Oid { get; set; }
        public int Cid { get; set; }
        public int Fid { get; set; }
        public string Date { get; set; }
        public int Quantity { get; set; }
        public int Chid { get; set; }
    }
}
