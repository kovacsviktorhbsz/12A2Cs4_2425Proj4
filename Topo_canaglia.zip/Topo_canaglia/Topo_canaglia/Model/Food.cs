﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Topo_canaglia.Model
{
    internal class Food
    {
        public int FId { get; set; }
        public string FName { get; set; }
        public string Category { get; set; }
        public int Cost { get; set; }
        public string Cuisine {  get; set; }
    }
}
