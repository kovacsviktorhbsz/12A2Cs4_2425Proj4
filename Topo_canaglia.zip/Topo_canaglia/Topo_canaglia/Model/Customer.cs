﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Topo_canaglia.Model
{
    internal class Customer
    {
        public int CId { get; set; }
        public string CNme { get; set; }
        public string EMail { get; set; }
        public int Phonenummer { get; set; }
    }
}
